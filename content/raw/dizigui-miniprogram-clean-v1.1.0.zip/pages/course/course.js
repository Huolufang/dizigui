const { days } = require('../../data/course')
const { getState } = require('../../utils/store')

Page({
  data: {
    activeStage: 0,
    stages: [
      { id: 0, label: '全部' },
      { id: 1, label: '孝悌' },
      { id: 2, label: '谨信' },
      { id: 3, label: '爱众与学文' }
    ],
    list: []
  },

  onShow() {
    this.refresh()
  },

  refresh() {
    const state = getState()
    const source = this.data.activeStage === 0
      ? days
      : days.filter((item) => item.stage === this.data.activeStage)
    const list = source.map((item) => {
      let status = 'pending'
      let statusText = '未开始'
      if (state.completedDays.includes(item.day)) {
        status = 'done'
        statusText = '已完成'
      } else if (item.day === state.currentDay) {
        status = 'doing'
        statusText = '进行中'
      } else if (item.day < state.currentDay) {
        status = 'missed'
        statusText = '待补学'
      }
      return {
        ...item,
        dayLabel: String(item.day).padStart(2, '0'),
        status,
        statusText,
        percent: state.dayProgress[item.day] || 0,
        originalText: item.units.length
          ? item.units.map((unit) => unit.text).join(' ')
          : '本日不增加新原文，进行累计复习与检测。'
      }
    })
    this.setData({ list })
  },

  selectStage(e) {
    this.setData({ activeStage: Number(e.currentTarget.dataset.id) }, () => this.refresh())
  },

  openDay(e) {
    const day = e.currentTarget.dataset.day
    wx.navigateTo({ url: `/pages/learn/learn?day=${day}` })
  }
})
