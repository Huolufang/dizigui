const { getState } = require('../../utils/store')

function stagePercent(completed, start, end) {
  const count = completed.filter((day) => day >= start && day <= end).length
  return Math.round(count / (end - start + 1) * 100)
}

Page({
  data: {
    state: null,
    stages: [],
    latestReflections: [],
    capacities: [],
    totalPercent: 0
  },

  onShow() {
    this.loadData()
  },

  onPullDownRefresh() {
    this.loadData()
    wx.stopPullDownRefresh()
  },

  loadData() {
    const state = getState()
    const completed = state.completedDays
    const recitation = state.recitationCoverage
    const understanding = Math.min(100, Math.round(completed.length / 21 * 100))
    const expression = Math.min(100, Math.round(state.reflections.length / 3 * 100))
    this.setData({
      state,
      totalPercent: Math.round(completed.length / 21 * 100),
      stages: [
        { title: '孝悌', range: '第1—7天', percent: stagePercent(completed, 1, 7), tone: 'lilac' },
        { title: '谨信', range: '第8—14天', percent: stagePercent(completed, 8, 14), tone: 'lime' },
        { title: '爱众与学文', range: '第15—21天', percent: stagePercent(completed, 15, 21), tone: 'cream' }
      ],
      capacities: [
        { label: '背诵覆盖', value: recitation, note: '按完成天数估算，正式版由逐句检测更新' },
        { label: '理解练习', value: understanding, note: '按已完成课程估算' },
        { label: '见解表达', value: expression, note: `${state.reflections.length}/3 次完整表达素材` }
      ],
      latestReflections: state.reflections.slice(-3).reverse()
    })
  },

  openGraduation() {
    wx.navigateTo({ url: '/pages/learn/learn?day=21' })
  }
})
