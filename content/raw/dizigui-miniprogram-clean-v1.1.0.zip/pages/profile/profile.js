const { getState, saveState, resetState } = require('../../utils/store')

Page({
  data: {
    state: null,
    minuteOptions: [10, 20, 30],
    version: '1.1.0'
  },

  onShow() {
    this.setData({ state: getState() })
  },

  chooseMinutes(e) {
    const state = getState()
    state.settings.dailyMinutes = Number(e.currentTarget.dataset.value)
    saveState(state)
    this.setData({ state })
  },

  toggleSetting(e) {
    const key = e.currentTarget.dataset.key
    const state = getState()
    state.settings[key] = e.detail.value
    saveState(state)
    this.setData({ state })
    if (key === 'reminder' && e.detail.value) {
      wx.showToast({ title: '已保存偏好', icon: 'none' })
    }
  },

  resetProgress() {
    wx.showModal({
      title: '清空本机学习记录？',
      content: '会删除完成天数、错句和见解记录，且无法恢复。',
      confirmText: '确认清空',
      confirmColor: '#c14343',
      success: (result) => {
        if (result.confirm) {
          this.setData({ state: resetState() })
          wx.showToast({ title: '已重置', icon: 'success' })
        }
      }
    })
  }
})
