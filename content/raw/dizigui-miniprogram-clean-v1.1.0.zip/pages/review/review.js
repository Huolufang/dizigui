const { getState, saveState } = require('../../utils/store')

Page({
  data: {
    state: null,
    pending: [],
    mastered: [],
    revealId: ''
  },

  onShow() {
    this.loadData()
  },

  onPullDownRefresh() {
    this.loadData()
    wx.stopPullDownRefresh()
  },

  loadData() {
    const state = getState()
    this.setData({
      state,
      pending: state.wrongSentences.filter((item) => item.status !== '已掌握'),
      mastered: state.wrongSentences.filter((item) => item.status === '已掌握')
    })
  },

  reveal(e) {
    const id = e.currentTarget.dataset.id
    this.setData({ revealId: this.data.revealId === id ? '' : id })
  },

  markMastered(e) {
    const id = e.currentTarget.dataset.id
    const state = getState()
    const item = state.wrongSentences.find((sentence) => sentence.id === id)
    if (item) item.status = '已掌握'
    state.reviewCount = state.wrongSentences.filter((sentence) => sentence.status !== '已掌握').length
    saveState(state)
    this.loadData()
    wx.showToast({ title: '已移入掌握区', icon: 'success' })
  },

  startDailyReview() {
    wx.navigateTo({ url: `/pages/learn/learn?day=${this.data.state.currentDay}` })
  }
})
