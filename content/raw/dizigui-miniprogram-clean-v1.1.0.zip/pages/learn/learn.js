const { getDay } = require('../../data/course')
const { getLectures } = require('../../data/lectures')
const {
  getState,
  saveState,
  completeDay,
  getDaySession,
  saveDaySession
} = require('../../utils/store')

const STEPS = [
  { key: 'review', label: '复习旧课' },
  { key: 'read', label: '朗读原文' },
  { key: 'understand', label: '理解原意' },
  { key: 'course', label: '课程讲解' },
  { key: 'recite', label: '背诵练习' },
  { key: 'reflect', label: '我的见解' },
  { key: 'quiz', label: '今日小测' },
  { key: 'summary', label: '今日总结' }
]

const REQUIRED_STEP_KEYS = STEPS.slice(0, 7).map((item) => item.key)

function normalize(text) {
  return String(text || '').replace(/[，。；、：？！“”‘’（）\s]/g, '')
}

function scoreText(target, actual) {
  const expected = normalize(target)
  const answer = normalize(actual)
  if (!expected.length || !answer.length) return 0
  let previous = Array.from({ length: answer.length + 1 }, (_, index) => index)
  for (let row = 1; row <= expected.length; row += 1) {
    const current = [row]
    for (let column = 1; column <= answer.length; column += 1) {
      const cost = expected[row - 1] === answer[column - 1] ? 0 : 1
      current[column] = Math.min(
        previous[column] + 1,
        current[column - 1] + 1,
        previous[column - 1] + cost
      )
    }
    previous = current
  }
  const distance = previous[answer.length]
  const longest = Math.max(expected.length, answer.length)
  return Math.max(0, Math.min(100, Math.round((1 - distance / longest) * 100)))
}

function parseLectureNumbers(label) {
  if (/完整40讲/.test(label)) return Array.from({ length: 40 }, (_, index) => index + 1)
  const range = label.match(/第(\d+)[—–-](\d+)讲/)
  if (range) {
    const start = Number(range[1])
    const end = Number(range[2])
    return Array.from({ length: end - start + 1 }, (_, index) => start + index)
  }
  const single = label.match(/第(\d+)讲/)
  return single ? [Number(single[1])] : []
}

function buildQuizItems(day, answers) {
  const source = answers || {}
  return [
    {
      id: 'understand-1',
      type: '理解题 1',
      prompt: `请用自己的话解释本节重点：${day.focus}`,
      input: source['understand-1'] || ''
    },
    {
      id: 'understand-2',
      type: '理解题 2',
      prompt: `请举一个不能机械套用的情况。提示：${day.boundary}`,
      input: source['understand-2'] || ''
    },
    {
      id: 'application-1',
      type: '应用题 1',
      prompt: '结合今天的原文，写下一个明天可以实际完成的小行动。',
      input: source['application-1'] || ''
    }
  ].map((item) => Object.assign({}, item, { complete: normalize(item.input).length >= 8 }))
}

function formatLectureParagraphs(lecture) {
  if (!lecture) return []
  return lecture.paragraphs.map((text, index) => ({
    id: `${lecture.number}-${index}`,
    text
  }))
}

Page({
  data: {
    day: null,
    steps: STEPS,
    stepIndex: 0,
    activeStep: STEPS[0],
    progress: 0,
    isCompleted: false,
    canContinue: false,
    previous: null,
    keywords: [],
    recitationInput: '',
    reflection: '',
    quizItems: [],
    hideOriginal: false,
    recitationResult: null,
    lectureOptions: [],
    activeLectureNumber: 0,
    activeLectureTitle: '',
    activeLectureParagraphs: [],
    checkpointTasks: [
      '累计原文背诵或随机抽查',
      '重点句白话解释',
      '一个现代生活情境分析',
      '完成一次五步见解表达'
    ]
  },

  onLoad(options) {
    const day = getDay(Number(options.day || 1))
    const state = getState()
    const session = getDaySession(day.day)
    const isCompleted = state.completedDays.includes(day.day)
    const previous = day.day > 1 ? getDay(day.day - 1) : null
    const lectureData = getLectures(parseLectureNumbers(day.cai.lecture))
    const savedReflection = session.reflection ||
      ((state.reflections.find((item) => item.dayNo === day.day) || {}).text || '')

    this.session = session
    this.lectureData = lectureData
    this.isCompleted = isCompleted

    const firstIncomplete = REQUIRED_STEP_KEYS.findIndex((key) => !session.completedSteps.includes(key))
    const stepIndex = isCompleted ? 0 : firstIncomplete === -1 ? 7 : firstIncomplete
    const firstLecture = lectureData[0] || null

    this.setData({
      day,
      previous,
      isCompleted,
      stepIndex,
      keywords: day.focus.split(/[、，。]/).filter(Boolean).slice(0, 5),
      recitationInput: session.recitationInput || '',
      recitationResult: session.recitationResult || null,
      reflection: savedReflection,
      quizItems: buildQuizItems(day, session.quizAnswers),
      lectureOptions: lectureData.map((item) => ({ number: item.number, title: `第${item.number}讲` })),
      activeLectureNumber: firstLecture ? firstLecture.number : 0,
      activeLectureTitle: firstLecture ? firstLecture.title : '',
      activeLectureParagraphs: formatLectureParagraphs(firstLecture)
    })
    this.refreshFlow(stepIndex)
    wx.setNavigationBarTitle({ title: `第${day.day}天 · ${day.chapter}` })
  },

  refreshFlow(preferredIndex) {
    const completedSet = new Set(this.isCompleted ? REQUIRED_STEP_KEYS : this.session.completedSteps)
    const firstIncomplete = REQUIRED_STEP_KEYS.findIndex((key) => !completedSet.has(key))
    const unlockThrough = this.isCompleted ? 7 : firstIncomplete === -1 ? 7 : firstIncomplete
    const steps = STEPS.map((item, index) => ({
      key: item.key,
      label: item.label,
      completed: this.isCompleted || completedSet.has(item.key),
      unlocked: this.isCompleted || index <= unlockThrough
    }))
    const stepIndex = Math.min(Number(preferredIndex), 7)
    const activeStep = steps[stepIndex]
    const completedCount = this.isCompleted
      ? 8
      : REQUIRED_STEP_KEYS.filter((key) => completedSet.has(key)).length
    const progress = this.isCompleted ? 100 : Math.round(completedCount / 8 * 100)
    const canContinue = this.isCompleted || Boolean(activeStep && activeStep.completed)

    const state = getState()
    state.dayProgress[this.data.day.day] = progress
    saveState(state)
    this.setData({ steps, stepIndex, activeStep, progress, canContinue })
  },

  persistSession() {
    saveDaySession(this.data.day.day, this.session)
  },

  setStepComplete(key) {
    if (!this.session.completedSteps.includes(key)) {
      this.session.completedSteps.push(key)
      this.persistSession()
    }
    this.refreshFlow(this.data.stepIndex)
  },

  finishCurrentAndNext() {
    this.setStepComplete(this.data.activeStep.key)
    if (this.data.stepIndex < 7) this.changeStep(this.data.stepIndex + 1)
  },

  selectStep(e) {
    const index = Number(e.currentTarget.dataset.index)
    const step = this.data.steps[index]
    if (!step.unlocked) {
      wx.showToast({ title: '请先完成前一环节', icon: 'none' })
      return
    }
    this.changeStep(index)
  },

  changeStep(index) {
    const step = this.data.steps[index]
    if (!step || !step.unlocked) return
    this.refreshFlow(index)
    wx.pageScrollTo({ scrollTop: 0, duration: 220 })
  },

  nextStep() {
    if (!this.data.canContinue) {
      wx.showToast({ title: '完成本环节后才能继续', icon: 'none' })
      return
    }
    if (this.data.stepIndex < 7) this.changeStep(this.data.stepIndex + 1)
  },

  previousStep() {
    if (this.data.stepIndex > 0) this.changeStep(this.data.stepIndex - 1)
  },

  selectLecture(e) {
    const number = Number(e.currentTarget.dataset.number)
    const lecture = this.lectureData.find((item) => item.number === number)
    if (!lecture) return
    this.setData({
      activeLectureNumber: lecture.number,
      activeLectureTitle: lecture.title,
      activeLectureParagraphs: formatLectureParagraphs(lecture)
    })
    wx.pageScrollTo({ scrollTop: 260, duration: 180 })
  },

  toggleOriginal() {
    this.setData({ hideOriginal: !this.data.hideOriginal })
  },

  onRecitationInput(e) {
    this.session.recitationInput = e.detail.value
    this.session.recitationResult = null
    this.persistSession()
    this.setData({ recitationInput: e.detail.value, recitationResult: null })
  },

  checkRecitation() {
    const input = this.data.recitationInput
    if (!this.data.day.units.length) {
      if (normalize(input).length < 8) {
        wx.showToast({ title: '请记录抽查内容或易错句', icon: 'none' })
        return
      }
      const result = {
        score: '完成',
        tone: 'good',
        message: '阶段背诵记录已保存，可以进入下一环节。'
      }
      this.session.recitationResult = result
      this.persistSession()
      this.setData({ recitationResult: result })
      this.setStepComplete('recite')
      return
    }

    const target = this.data.day.units.map((unit) => unit.text).join('')
    const score = scoreText(target, input)
    const result = {
      score: `${score}%`,
      tone: score >= 90 ? 'good' : score >= 70 ? 'medium' : 'needs-work',
      message: score >= 90
        ? '整体顺序和文字已经很稳。'
        : score >= 70
          ? '本次已达到解锁标准，错漏部分会进入复习清单。'
          : '尚未达到70%，请缩小到一组原文练习后再试。'
    }
    this.session.recitationResult = result
    this.persistSession()
    this.setData({ recitationResult: result })
    if (score >= 70) this.setStepComplete('recite')

    if (score < 90 && this.data.day.units[0]) {
      const state = getState()
      const unit = this.data.day.units[0]
      const existing = state.wrongSentences.find((item) => item.id === unit.id)
      if (existing) {
        existing.times += 1
        existing.status = '待复习'
      } else {
        state.wrongSentences.push({
          id: unit.id,
          text: unit.text,
          error: '本次文字背诵未达到90%，请重点核对漏字和句序',
          times: 1,
          status: '待复习'
        })
      }
      state.reviewCount = state.wrongSentences.filter((item) => item.status !== '已掌握').length
      saveState(state)
    }
  },

  onReflectionInput(e) {
    const reflection = e.detail.value
    this.session.reflection = reflection
    this.persistSession()
    this.setData({ reflection })
    if (normalize(reflection).length >= 8) this.setStepComplete('reflect')
  },

  onQuizItemInput(e) {
    const index = Number(e.currentTarget.dataset.index)
    const item = this.data.quizItems[index]
    const value = e.detail.value
    const inputKey = `quizItems[${index}].input`
    const doneKey = `quizItems[${index}].complete`
    this.session.quizAnswers[item.id] = value
    this.persistSession()
    this.setData({
      [inputKey]: value,
      [doneKey]: normalize(value).length >= 8
    })
    const allDone = this.data.quizItems.every((quizItem, itemIndex) => {
      const current = itemIndex === index ? value : quizItem.input
      return normalize(current).length >= 8
    })
    if (allDone) this.setStepComplete('quiz')
  },

  finishDay() {
    const missing = REQUIRED_STEP_KEYS.find((key) => !this.session.completedSteps.includes(key))
    if (missing && !this.isCompleted) {
      const index = STEPS.findIndex((item) => item.key === missing)
      wx.showToast({ title: '还有环节尚未完成', icon: 'none' })
      this.changeStep(index)
      return
    }
    completeDay(this.data.day.day, this.data.reflection.trim())
    this.isCompleted = true
    this.setData({ isCompleted: true })
    this.refreshFlow(7)
    wx.showToast({ title: '今日学习完成', icon: 'success' })
    setTimeout(() => {
      if (this.data.day.day === 21) {
        wx.switchTab({ url: '/pages/report/report' })
      } else {
        wx.switchTab({ url: '/pages/home/home' })
      }
    }, 650)
  }
})
