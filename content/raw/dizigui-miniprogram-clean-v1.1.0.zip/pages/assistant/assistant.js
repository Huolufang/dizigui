const { getDay } = require('../../data/course')
const { getState } = require('../../utils/store')

Page({
  data: {
    day: null,
    input: '',
    messages: [],
    quickQuestions: ['今天学什么？', '怎样帮助孩子背诵？', '蔡老师怎样讲？', '现代应用边界是什么？']
  },

  onLoad() {
    const state = getState()
    const day = getDay(state.currentDay)
    this.setData({
      day,
      messages: [{
        id: 'assistant-welcome',
        role: 'assistant',
        source: '课程导览',
        text: `今天是第${day.day}天“${day.chapter}”。你可以问原文、背诵方法、蔡老师的相关讲解或现代应用边界。`
      }]
    })
  },

  onInput(e) {
    this.setData({ input: e.detail.value })
  },

  useQuickQuestion(e) {
    this.answer(e.currentTarget.dataset.question)
  },

  send() {
    this.answer(this.data.input)
  },

  answer(question) {
    const text = String(question || '').trim()
    if (!text) return
    const day = this.data.day
    let answer = null
    if (/蔡|老师|课程|讲解/.test(text)) {
      answer = {
        source: `蔡老师相关讲解 · ${day.cai.lecture}`,
        text: `${day.cai.points.join('；')}。课程案例：${day.cai.case}`
      }
    } else if (/现代|边界|误解|服从|适用/.test(text)) {
      answer = {
        source: '现代说明 · 不是原文',
        text: day.boundary
      }
    } else if (/背|记|复习|错字/.test(text)) {
      const first = day.units[0] ? day.units[0].text : day.focus
      answer = {
        source: '背诵建议',
        text: `先只练这一组：“${first}”分句跟读三遍，再用关键词提示、上句接下句和无提示背诵逐步减少帮助。一次只纠正最重要的一处。`
      }
    } else {
      answer = {
        source: '《弟子规》今日原文与主题',
        text: day.units.length
          ? `${day.units.map((unit) => unit.text).join(' ')} 本节重点是：${day.focus}`
          : `今天是阶段任务，不增加新原文。重点是：${day.focus}`
      }
    }
    const timestamp = Date.now()
    this.setData({
      input: '',
      messages: this.data.messages.concat(
        { id: `user-${timestamp}`, role: 'user', source: '家长提问', text },
        { id: `assistant-${timestamp}`, role: 'assistant', source: answer.source, text: answer.text }
      )
    })
    setTimeout(() => wx.pageScrollTo({ scrollTop: 99999, duration: 220 }), 60)
  },

  startDay() {
    wx.navigateTo({ url: `/pages/learn/learn?day=${this.data.day.day}` })
  }
})
