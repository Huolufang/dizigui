const { getDay } = require('../../data/course')
const { getState } = require('../../utils/store')

Page({
  data: {
    day: null,
    state: null,
    progress: 0,
    unitPreview: '',
    actionDone: false,
    targetCards: [
      { key: '背', title: '能够背诵', copy: '递减提示、错句重练与间隔复习', tone: 'lilac' },
      { key: '懂', title: '能够理解', copy: '原意、课程讲解与现代边界分开', tone: 'lime' },
      { key: '讲', title: '讲出见解', copy: '引用原文、联系现实并提出行动', tone: 'cream' }
    ]
  },

  onShow() {
    this.loadData()
  },

  onPullDownRefresh() {
    this.loadData()
    wx.stopPullDownRefresh()
  },

  loadData() {
    const state = getState()
    const day = getDay(state.currentDay)
    this.setData({
      day,
      dayLabel: String(day.day).padStart(2, '0'),
      state,
      progress: state.dayProgress[day.day] || 0,
      unitPreview: day.units[0] ? day.units[0].text : day.focus,
      actionDone: Boolean(wx.getStorageSync(`action_day_${day.day}`))
    })
  },

  startLearning() {
    wx.navigateTo({ url: `/pages/learn/learn?day=${this.data.day.day}` })
  },

  openCourse() {
    wx.switchTab({ url: '/pages/course/course' })
  },

  openAssistant() {
    wx.navigateTo({ url: '/pages/assistant/assistant' })
  },

  toggleAction() {
    const next = !this.data.actionDone
    wx.setStorageSync(`action_day_${this.data.day.day}`, next)
    this.setData({ actionDone: next })
  }
})
