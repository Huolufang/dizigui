const { ensureState } = require('./utils/store')

App({
  globalData: {
    productName: '弟子规学堂',
    apiBaseUrl: '',
    contentVersion: '1.1.0'
  },

  onLaunch() {
    ensureState()
  }
})
