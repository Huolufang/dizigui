function request(path, options) {
  const app = getApp()
  const baseUrl = app.globalData.apiBaseUrl
  if (!baseUrl) {
    return Promise.reject(new Error('API_BASE_URL_NOT_CONFIGURED'))
  }

  return new Promise((resolve, reject) => {
    wx.request({
      url: `${baseUrl}${path}`,
      method: options.method || 'GET',
      data: options.data || {},
      header: options.header || {},
      success: (res) => {
        if (res.statusCode >= 200 && res.statusCode < 300) resolve(res.data)
        else reject(new Error(`HTTP_${res.statusCode}`))
      },
      fail: reject
    })
  })
}

module.exports = {
  getDayConfig(dayNo) {
    return request(`/v1/course/days/${dayNo}`, {})
  },
  searchCourseMaterials(unitIds) {
    return request('/v1/ai/tools/search-course-materials', {
      method: 'POST',
      data: { unit_ids: unitIds }
    })
  },
  saveLearningEvent(payload) {
    return request('/v1/learning/events', { method: 'POST', data: payload })
  }
}
