const KEY = 'dizigui_learning_state_v1'

const DEFAULT_STATE = {
  currentDay: 1,
  completedDays: [],
  dayProgress: {},
  daySessions: {},
  streak: 0,
  recitationCoverage: 0,
  reviewCount: 0,
  wrongSentences: [],
  reflections: [],
  settings: {
    dailyMinutes: 20,
    showPinyin: false,
    voiceFirst: false,
    reminder: false
  }
}

function clone(value) {
  return JSON.parse(JSON.stringify(value))
}

function ensureState() {
  const state = wx.getStorageSync(KEY)
  if (!state) {
    wx.setStorageSync(KEY, clone(DEFAULT_STATE))
    return clone(DEFAULT_STATE)
  }
  const merged = Object.assign({}, clone(DEFAULT_STATE), state, {
    dayProgress: Object.assign({}, DEFAULT_STATE.dayProgress, state.dayProgress || {}),
    daySessions: Object.assign({}, DEFAULT_STATE.daySessions, state.daySessions || {}),
    settings: Object.assign({}, DEFAULT_STATE.settings, state.settings || {}),
    completedDays: state.completedDays || [],
    wrongSentences: state.wrongSentences || [],
    reflections: state.reflections || []
  })
  wx.setStorageSync(KEY, merged)
  return merged
}

function getState() {
  return ensureState()
}

function saveState(state) {
  wx.setStorageSync(KEY, state)
  return state
}

function updateState(patch) {
  const state = getState()
  const next = Object.assign({}, state, patch)
  return saveState(next)
}

function getDaySession(dayNo) {
  const state = getState()
  const saved = state.daySessions[dayNo] || {}
  return Object.assign({
    completedSteps: [],
    recitationInput: '',
    recitationResult: null,
    reflection: '',
    quizAnswers: {}
  }, saved, {
    completedSteps: saved.completedSteps || [],
    quizAnswers: saved.quizAnswers || {}
  })
}

function saveDaySession(dayNo, session) {
  const state = getState()
  state.daySessions[dayNo] = session
  saveState(state)
  return session
}

function completeDay(dayNo, reflection) {
  const state = getState()
  const completed = Array.from(new Set(state.completedDays.concat(dayNo))).sort((a, b) => a - b)
  const dayProgress = Object.assign({}, state.dayProgress, { [dayNo]: 100 })
  const reflections = state.reflections.filter((item) => item.dayNo !== dayNo)
  if (reflection) reflections.push({ dayNo, text: reflection, createdAt: Date.now() })
  return saveState(Object.assign({}, state, {
    completedDays: completed,
    dayProgress,
    reflections,
    currentDay: Math.min(21, Math.max(state.currentDay, dayNo + 1)),
    streak: Math.max(state.streak, completed.length),
    recitationCoverage: Math.min(100, Math.round(completed.length / 21 * 100))
  }))
}

function resetState() {
  const state = clone(DEFAULT_STATE)
  wx.setStorageSync(KEY, state)
  return state
}

module.exports = {
  KEY,
  DEFAULT_STATE,
  ensureState,
  getState,
  saveState,
  updateState,
  getDaySession,
  saveDaySession,
  completeDay,
  resetState
}
